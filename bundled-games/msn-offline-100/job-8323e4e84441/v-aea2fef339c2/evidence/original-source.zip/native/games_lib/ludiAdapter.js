//#region wiinvent
if (document.domain == "cdn-gameloft.digiplay.vn") {
  {
    window.AdsState = {
      NONE: 0,
      LOADING: 1,
      LOADED: 2,
      STARTED: 3,
      COMPLETE: 4,
    };
    window.adsCurrentState = window.AdsState.NONE;
    window._setAdsState = function (state) {
      var oldState = window.adsCurrentState;
      window.adsCurrentState = state;
      window.dispatchEvent(
        new CustomEvent("gl_ads_state_change", {
          detail: { oldState: oldState, newState: window.adsCurrentState },
        })
      );
    };
    window.isAdsComplete = function () {
      return window.adsCurrentState == window.AdsState.COMPLETE;
    };
  }

  window.dataLayer = [];
  window.enableADS = !false;
  window.productKey = "";
  window.productTitle = "";

  window.ARSlotState = 0;
  window.myAdsReward = 0;

  window.isShowAdScreen = false;

  function adDone() {
    window._setAdsState(AdsState.STARTED);
    window._setAdsState(AdsState.COMPLETE);
    window.focus();
    console.log("ads done");
  }

  window.playAds = function () {
    adDone();
  };

  window.show_freeFrame = function () {
    adDone();
  };
  window.show_freeFrame_Loc = function (l) {
    adDone();
  };

  window.getReferrer = function () {
    return "";
  };
  window.getDefault = function (key) {
    return 0;
  };

  function setCookie(cname, cvalue) {
    var d = new Date();
    d.setTime(d.getTime() + 1 * 365 * 24 * 60 * 60 * 1000);
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  window.addEventListener("load", function (event) {
    var bodyEle = document.getElementsByTagName("body")[0];
    window.adsContainer = document.createElement("div");
    window.adsContainer.id = "adsContainer";
    window.adsContainer.style.display = "none";
    bodyEle.appendChild(adsContainer);
    adDone();
  });
} else {
  //#region v3
  {
    window.AdsState = {
      NONE: 0,
      LOADING: 1,
      LOADED: 2,
      STARTED: 3,
      COMPLETE: 4,
    };
    window.adsCurrentState = window.AdsState.NONE;
    window.showPlacementCount = 0;
    window.adRequestCount = 0;
    window.reShowSticky = false;
    window._setAdsState = function (state) {
      if (state == window.AdsState.COMPLETE && window.bg_div) {
        window.displayAdBG(false);
      }
      var oldState = window.adsCurrentState;
      window.adsCurrentState = state;
      window.dispatchEvent(
        new CustomEvent("gl_ads_state_change", {
          detail: { oldState: oldState, newState: window.adsCurrentState },
        })
      );
      if (window.parent) {
        window.parent.adsCurrentState = state;
        window.parent.dispatchEvent(
          new CustomEvent("gl_ads_state_change", {
            detail: { oldState: oldState, newState: window.adsCurrentState },
          })
        );
      }
    };
    window.isAdsComplete = function () {
      return window.adsCurrentState == window.AdsState.COMPLETE;
    };
  }
  if (!parent.window.isUseADXOnly && window.parent.isUseCombineAd && !window.parent.disableAds) {
    var adsbygoogle_script = document.createElement("script");
    //adsbygoogle_script.setAttribute('async', true);
    adsbygoogle_script.async = true;
    adsbygoogle_script.setAttribute(
      "data-ad-client",
      "ca-pub-4052078165537812"
    );
    adsbygoogle_script.setAttribute("data-ad-channel", parent.window._cc_afc);
    adsbygoogle_script.setAttribute("data-ad-frequency-hint", "120s");

    try {
      if (
        window.location.ancestorOrigins &&
        window.location.ancestorOrigins.length > 0
      ) {
        if (window.location.ancestorOrigins[0].indexOf("localhost") >= 0) {
          adsbygoogle_script.setAttribute("data-adbreak-test", "on");
        }
      }
    } catch (e) {}
    // if(window.location.href.indexOf("gameloftSlotMachineFree") >= 0){
    // adsbygoogle_script.setAttribute('data-ad-frequency-hint', '60s');
    // }
    adsbygoogle_script.setAttribute(
      "src",
      "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
    );
    document.head.appendChild(adsbygoogle_script);
    //document.getElementById("adsbygoogle").dataset.ad-channel = parent.window._cc_afg;

    
  }
	window.H5PlacementInitState = 0;
	function onH5PlacementReady(pos){
		if(pos == "preroll") 
			showAd3(pos,true);
		else
			setTimeout(function(){showAd3(pos,true)},window.parent.AD_LOAD_TIMEOUT);
	}
	function initH5Placement(pos){
		if(window.H5PlacementInitState == 0){
			console.log("init h5 ad placement");
			window.H5PlacementInitState = 1;
			window.adsbygoogle = window.adsbygoogle || [];
			window.adBreak = (adConfig = function (o) {
				adsbygoogle.push(o);
			});
			if (window.location.href.indexOf("asphaltRetroFree") >= 0) {
				adConfig({
					preloadAdBreaks: window.parent.preloadAd ? "on" : "auto",
					onReady: onH5PlacementReady(pos),
					adUnitId: "3384716122",
				});
			} else {
				adConfig({
					preloadAdBreaks: window.parent.preloadAd ? "on" : "auto",
					onReady: onH5PlacementReady(pos),
				});
			}
		}
	}
  function showAd(pos) {
    showAd2(pos, false);
  }
  function showAd2(pos, isPlacement) {
		if(Date.now() - window.lastShowAds < 30000){
			console.log("msstart: cancel backfill due hold period");
			adDone();
			return;
		}
    // Show an ad
    if (window.parent.disableAds) {
      window._setAdsState(AdsState.STARTED);
      window._setAdsState(AdsState.COMPLETE);
      window.focus();
      return;
    }
    window.adRequestCount += 1;
    if (pos == "preroll" && window.parent.isDiableFirstAd) {
      console.log("disable first ad");
      window._setAdsState(AdsState.STARTED);
      window._setAdsState(AdsState.COMPLETE);
      window.parent.displayGameSticky(!false);
      window.reShowSticky = true;
      window.focus();
      return;
    }
    if (window.parent.isDiableSecondAd && window.adRequestCount == 2) {
      console.log("disable second ad");
      window._setAdsState(AdsState.STARTED);
      window._setAdsState(AdsState.COMPLETE);
      window.parent.displayGameSticky(!false);
      window.reShowSticky = true;
      window.focus();
      return;
    }
    /*if (pos == "preroll" && parent.window.flowADXH5Ima3) {
      window.setTimeout(function () {
        if (!window.parent.gameManualInterstitialShowPreroll) {
          window.parent.gameManualInterstitialShowPreroll = true;
          adBreak({
            type: "preroll",
            adBreakDone: function (info) {
              window.refreshSticky();
              window._setAdsState(AdsState.COMPLETE);

              window.focus();
              console.log("ads placement done");
            },
          });
        }
      }, 4000);
			
      return;
    }*/
    if(!parent.window.isUseADXOnly && isPlacement && window.H5PlacementInitState == 0){
			initH5Placement(pos);
			return;
		}
		showAd3(pos, isPlacement);
  }
	function showAd3(pos, isPlacement) {
		if (
      window.parent.sticky_div &&
      window.parent.sticky_div.style.display != "none"
    ) {
      window.parent.displayGameSticky(false);
      window.reShowSticky = true;
    }
    window.showPlacementCount++;
		if(window.adsCurrentState != AdsState.STARTED)
			window._setAdsState(AdsState.STARTED);
    if (window.bg_div) {
      window.displayAdBG(true);
    }
    if (parent.window.isUseADXOnly || (!isPlacement && window.parent.flowADXH5Ima3)) {
      window.parent.showAdx(pos);
    } else {
      adBreak({
        type: pos,
        adBreakDone: function (info) {
          //console.log(info);
          if (
            !window.parent.isUseCombineAd ||
            info.breakStatus == "viewed" ||
            info.breakStatus == "dismissed"
          ) {
            window.refreshSticky();
            window._setAdsState(AdsState.COMPLETE);

            window.focus();
            if(info.breakStatus == 'viewed' || info.breakStatus == 'dismissed'){
							window.lastShowAds = Date.now();
							console.log("msstart: backfill placement ads played");
						}else{
							// if(parent.window.ga_channel_name == "PH72"){
								// window.parent.playAds();
							// }else{
								// window.parent.showGameManualInterstitial();
							// }
							console.log("msstart: backfill ads placement done");
						}
          } else {
						window.refreshSticky();
            window._setAdsState(AdsState.COMPLETE);
            window.focus();
						console.log("msstart: backfill ads placement done");
            /*if (parent.window.flowADXH5Ima3) {
              window.parent.playAds();
							console.log("h5 placement not show");
							console.log(info);
            } else {
              window.parent.showAdx(pos);
            }*/
          }
        },
      });
    }
    //window.lastShowAds = Date.now();
	}
  window.refreshSticky = function () {
    if (window.reShowSticky) {
      window.reShowSticky = false;
      window.parent.displayGameSticky(true);
    }
  };
  function adDone() {
    if (window.refreshSticky) window.refreshSticky();
    window._setAdsState(AdsState.COMPLETE);

    window.focus();
    console.log("ads done");
  }
  window.myDataLayer = function () {
    var arr = [];
    arr.push = function () {
      //console.log("PUSHING", arguments);
      window.parent.dataLayer.push(arguments[0]);
      return Array.prototype.push.apply(this, arguments);
    };

    return arr;
  };

  window.dataLayer = new window.myDataLayer();
  window.enableADS = window.parent.enableADS;
  window.productKey = window.parent.productKey;
  window.productTitle = window.parent.productTitle;

  if (window.parent.adsContainer) {
    window.adsContainer = window.parent.adsContainer;
  }
  if (!window.parent.isUseCombineAd) {
    if (window.parent.AdsState) {
      window.AdsState = window.parent.AdsState;
    }
    if (window.parent.adsCurrentState) {
      window.adsCurrentState = window.parent.adsCurrentState;
    }
    window.isAdsComplete = function () {
      return window.parent.isAdsComplete();
    };
  }
	window.canPlayAds = function(){
		if(window.parent.midAdRule.length > 0){
			for(var i = 0; i < window.parent.midAdRule.length; i++){
				if(window.parent.midAdRule[i].enable){
					if(window.parent.midAdRule[i].rule[0] == window.parent.NUMBER_OF_PLAY_PER_AD){
						if(window.parent.midAdRule[i].ruleCurr == undefined){
							window.parent.midAdRule[i].ruleCurr = 1;
						}else{
							window.parent.midAdRule[i].ruleCurr ++;
						}
						if(window.parent.midAdRule[i].ruleCurr >= window.parent.midAdRule[i].rule[1]){
							window.parent.midAdRule[i].ruleCurr = 0;
							return true;
						}else{
							return false;
						}
					}
				}
			}
		}
		return true;
	}
  window.playAds = function () {
		window._setAdsState(AdsState.STARTED);
		window.parent.parent.mssw.playAds({adFormat: window.parent.parent.mssw.AD_FORMAT.INTERSTITIAL});
  };
  window.getReferrer = function () {
    return window.parent.getReferrer();
  };
  window.setCookie = function (cname, cvalue) {
    window.parent.setCookie(cname, cvalue);
  };
  window.getCookie = function (cname) {
    return window.parent.getCookie(cname);
  };
  window.show_freeFrame = function () {
		window._setAdsState(AdsState.STARTED);
		window.parent.parent.mssw.playAds({adFormat: window.parent.parent.mssw.AD_FORMAT.INTERSTITIAL});
  };
  window.show_freeFrame_Loc = function (l) {
		window._setAdsState(AdsState.STARTED);
		window.parent.parent.mssw.playAds({adFormat: window.parent.parent.mssw.AD_FORMAT.INTERSTITIAL});
  };

  window.myConsoleLog = function () {
    return window.parent.myConsoleLog();
  };
  window.myConsole = window.parent.myConsole;

  // adsRewardSDK
  window.ARSlotState = window.parent.ARSlotState;
  window.myAdsReward = window.parent.myAdsReward;

  // AS
  window.getDefault = function (key) {
    return window.parent.getDefault(key);
  };
  //#region eruda
  window.erudaObj = window.erudaObj || {
    touchCount: 0,
    leftClickCount: 0,
    rightClickCount: 0,
    hasEruda: false,
    touchHandler: function (event) {
      // console.log('3. Body listener (CAPTURING phase) - Đã bắt được click!', event, this);
      erudaObj.touchCount++;
      if (erudaObj.touchCount > 20) {
        // console.log(`touchCount: ${touchCount}`);
        document.body.removeEventListener(
          "touchstart",
          erudaObj.touchHandler,
          true
        );
      }
      if (event.touches[0].clientX < 50 && event.touches[0].clientY < 50) {
        // console.log(`touchend, leftClickCount: ${erudaObj.leftClickCount}`)
        if (erudaObj.rightClickCount == 0) erudaObj.leftClickCount++;
        else erudaObj.leftClickCount = 0;
      }
      if (
        event.touches[0].clientX > window.innerWidth - 50 &&
        event.touches[0].clientY < 50
      ) {
        // console.log(`touchend, rightClickCount: ${erudaObj.rightClickCount}`)
        if (erudaObj.leftClickCount == 7) erudaObj.rightClickCount++;
        else erudaObj.rightClickCount = 0;
      }
      if (
        erudaObj.leftClickCount == 7 &&
        erudaObj.leftClickCount + erudaObj.rightClickCount == 15
      ) {
        erudaObj.hasEruda = true;
      }

      if (
        erudaObj.hasEruda &&
        devicePixelRatio == 2.625 &&
        window.innerWidth == 411
      ) {
        //load eruda
        window.parent.loadEruda();
        document.body.removeEventListener(
          "touchstart",
          erudaObj.touchHandler,
          true
        );
      }
    },
  };

  //#endregion

  window.isShowAdScreen = false;

  // auto ads every 2s
  window.lastShowAds = Date.now();
	// for game wait preroll ad complete to start game
	adDone();
	
	//----------- adsRewardSDK
	//window.ARSlotState = window.parent.ARSlotState;
	//window.myAdsReward = window.parent.myAdsReward;

	var myAdsReward = {
		/*OnRewardReadyCallback: null,
		OnRewardGrantedCallback: null,
		OnRewardClosedCallback: null,*/
		displayRewardedSlot(reward_adUnitPath, OnRewardReady, OnRewardGranted, OnRewardClosed) {
			/*this.OnRewardReadyCallback = OnRewardReady;
			this.OnRewardGrantedCallback = OnRewardGranted;
			this.OnRewardClosedCallback = OnRewardClosed;*/
			window.parent.parent.mssw.playRewardAds({adFormat: window.parent.parent.mssw.AD_FORMAT.REWARD},OnRewardReady, OnRewardGranted, OnRewardClosed);
		},
		makeRewardedVisible(){
			window.parent.parent.mssw.showRewardAd();
		}
	}
	window.parent.myAdsReward = myAdsReward;
// end ad reward------------------
  /*if (window.parent.isAutoAds) {
    window.autoAdsInterval = setInterval(function () {
      if (Date.now() - window.lastShowAds > 120000) {
        showAd("next");
      }
    }, 1000);
  }
  if (!window.parent.disableAds) {
		window._setAdsState(AdsState.STARTED);
		if(!parent.window.isDiableFirstAd){
			setTimeout(function(){
				if(!parent.window.isUseADXOnly && !parent.window.gameManualInterstitialShowPreroll && window.H5PlacementInitState == 0){
					parent.window.gameManualInterstitialShowPreroll = true;
					initH5Placement("preroll");
				}
			},window.parent.AD_LOAD_TIMEOUT + 300);
		}else{
			parent.window.gameManualInterstitialShowPreroll = true;
			window._setAdsState(AdsState.COMPLETE);
			window.focus();
		}
  } else {
    // for game hardcode wait first ad complete to start game
    window._setAdsState(AdsState.STARTED);
    window._setAdsState(AdsState.COMPLETE);
    window.focus();
  }*/
  window.displayAdBG = function (show) {
    if (show) {
      if (window.bg_div) {
        window.bg_div.style.display = "inline";
        window.setTimeout(function () {
          window.bg_div.style.display = "none";
        }, 3000);
      }
    } else {
      if (window.bg_div) {
        window.bg_div.style.display = "none";
      }
    }
  };
  window.addEventListener("load", function (event) {
    if (window.parent.preloadAd) {
      var bodyEle = document.getElementsByTagName("body")[0];
      window.bg_div = document.createElement("div");
      window.bg_div.id = "bg-ad";
      window.bg_div.style.position = "fixed";
      window.bg_div.style.display = "none";
      window.bg_div.style.width = "100%";
      window.bg_div.style.height = "100%";
      window.bg_div.style.top = "0px";
      window.bg_div.style.left = "0px";
      //window.bg_div.style.backgroundColor = "#000000ff";
      //window.bg_div.appendChild(document.createTextNode("Ad Loading..."));
      function stopInput(event) {
        if (event && event.stopPropagation) {
          try {
            event.stopPropagation();
          } catch (e) {}
        }
      }
      bg_div.addEventListener("touchstart", stopInput);
      bg_div.addEventListener("touchmove", stopInput);
      bg_div.addEventListener("touchend", stopInput);
      bg_div.addEventListener("touchleave", stopInput);
      bg_div.addEventListener("touchcancel", stopInput);
      bg_div.addEventListener("mousedown", stopInput);
      bg_div.addEventListener("mouseleave", stopInput);
      bg_div.addEventListener("mousemove", stopInput);
      bg_div.addEventListener("mouseup", stopInput);
      bg_div.addEventListener("mouseover", stopInput);
      bodyEle.appendChild(bg_div);
    }

    document.body.addEventListener("touchstart", erudaObj.touchHandler, true);
  });
}
