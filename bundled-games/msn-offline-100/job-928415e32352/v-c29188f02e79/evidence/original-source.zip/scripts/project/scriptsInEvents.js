function InitExternEval() 
    {
		console.log("InitExternEval");
       
    }
	
	function TakeReward()
	{
		window.adReward = 0;
	}
	
	function RewardErrorHandled()
	{
		
	}
	

		
		function ExternEval() 
		{
			console.log("ExternEval");
		}
		
		function PreloadRewarded() 
		{
			
		}
		
		function ShowRewarded() 
		{
			window.adReward = 1;
		}
		
		function isMobile() { return ('ontouchstart' in document.documentElement); }
		
		function OpenLink()
		{
			try
			{
				if (isMobile() == false)
				{
					document.onmouseup = function()
					{
						window.open("https://www.julgames.com");
						document.onmouseup = null;
					}
				}
			}
			catch(e){  }
		}
	
		window.adRunning = 0;
		window.adReward = 0;
		window.rewardError = 0;
		window.canReward = 1;
		
		window.callTime = 0;
		window.adPlatform = 5;
		window.freezenova = "www.FreezeNova.com";
	


const scriptsInEvents = {

	async Game_sheet_Event77_Act3(runtime, localVars)
	{
		ShowRewarded();
	},

	async Game_sheet_Event78_Act1(runtime, localVars)
	{
		TakeReward();
	},

	async Levelsselection_Event1_Act2(runtime, localVars)
	{
		ExternEval();
	},

	async Menu_Event1_Act1(runtime, localVars)
	{
		InitExternEval();
	},

	async Menu_Event1_Act2(runtime, localVars)
	{
		if (typeof window.freezenova !== 'undefined') {
			runtime.globalVars.linktxt = window.freezenova;
		}
		
	},

	async Ads_Event1_Act1(runtime, localVars)
	{
		runtime.globalVars.adActive = window.adRunning;
	},

	async Ads_Event1_Act2(runtime, localVars)
	{
		runtime.globalVars.adReward = window.adReward;
	},

	async Ads_Event1_Act3(runtime, localVars)
	{
		runtime.globalVars.canReward = window.canReward;
	},

	async Ads_Event6_Act1(runtime, localVars)
	{
		console.log("Pressed K");
		window.adRunning = 1;
	},

	async Ads_Event7_Act1(runtime, localVars)
	{
		console.log("Pressed L");
		window.adRunning = 0;
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

