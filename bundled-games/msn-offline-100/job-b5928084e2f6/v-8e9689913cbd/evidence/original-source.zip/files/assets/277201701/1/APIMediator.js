///@ts-nocheck
class APIMediator {

    static log(...args) {
        window.GameInterface.log(...args);
    }

    /* features */
    static hasFeature(feature) {
        if (typeof this._features === 'undefined') this._features = {};
        if (typeof this._features[feature] === 'undefined') this._features[feature] = window.GameInterface.hasFeature(feature);
        return this._features[feature];
    }

    static isPlaycanvasEnvironment() {
        return window.location.host === 'launch.playcanvas.com' || window.location.host === 'playcanv.as'
    }

    static sendPreloadProgress(value) {
        this._lastReportedLoadingProgress = this._lastReportedLoadingProgress || 0;
        value = Math.floor(Math.min(100, Math.max(0, value)));
        if (value > this._lastReportedLoadingProgress) {
            this._lastReportedLoadingProgress = value;
            window.GameInterface.sendPreloadProgress(this._lastReportedLoadingProgress);
        }
    }

    static reportGameReady() {
        APIMediator.gameReadyReported = true;
        window.GameInterface.gameReady();
    }


    static async gameStart(level) {
        return window.GameInterface.gameStart(level);
    }

    static async gamePause() {
        await window.GameInterface.gamePause();
    }

    static async gameResume() {
        await window.GameInterface.gameResume();
    }

    static async gameComplete() {
        return window.GameInterface.gameComplete();
    }

    static async gameOver() {
        return window.GameInterface.gameOver();
    }

    static async gameQuit() {
        return window.GameInterface.gameQuit();
    }

    /* stages reporting */

    static async stageStart(stage) {
        return window.GameInterface.stageStart(stage);
    }

    static async stageComplete() {
        return window.GameInterface.stageComplete();
    }

    static async stageOver() {
        return window.GameInterface.stageOver();
    }

    static async stageQuit() {
        return window.GameInterface.stageQuit();
    }

    /* score reporting */

    static sendLiveScore(value, forced = false) {
        this._lastReportedLiveScore = this._lastReportedLiveScore || 0;
        if (this._lastReportedLiveScore !== value || forced) {
            this._lastReportedLiveScore = value;

            if (APIMediator.hasFeature('score')) {
                window.GameInterface.sendScore(this._lastReportedLiveScore, {type: 'live', level: GameplayController.currentLevel});
            }
        }
    }

    static sendLevelScore(value, forced = true) {
        this._lastReportedLevelScore = this._lastReportedLevelScore || 0;
        if (this._lastReportedLevelScore !== value || forced) {
            this._lastReportedLevelScore = value;

            if (APIMediator.hasFeature('score')) {
                window.GameInterface.sendScore(this._lastReportedLevelScore, {type: 'level', level: GameplayController.currentLevel});
            }
        }
    }

    static sendTotalScore(value, forced = true) {
        this._lastReportedTotalScore = this._lastReportedTotalScore || 0;
        if (this._lastReportedTotalScore !== value || forced) {
            this._lastReportedTotalScore = value;

            if (APIMediator.hasFeature('score')) {
                window.GameInterface.sendScore(this._lastReportedTotalScore, {type: 'total'});
            }
        }
    }

    static sendProgress(value, forced = false) {
        this._lastReportedProgress = this._lastReportedProgress || 0;
        value = Math.floor(Math.min(100, Math.max(0, value)));
        if (this._lastReportedProgress !== value || forced) {
            this._lastReportedProgress = value;

            if (APIMediator.hasFeature('progress')) {
                window.GameInterface.sendProgress(this._lastReportedProgress);
            }
        }
    }


    /** localization */
    static getCurrentLanguage() {
        return GameInterface.getCurrentLanguage();
    }


    /** interstitials **/
    static disableAds() {
        window.GameInterface.sendEvent('disableAds');
    }

    static async showInterstitialAd(eventId, placementType) {
        return window.GameInterface.showInterstitialAd(eventId, placementType);
    };


    /* rewarded ads */

    static areRewardedAdsSupported() {
        if (typeof this._rewardedFeatureEnabled === 'undefined') this._rewardedFeatureEnabled = window.GameInterface.hasFeature("rewarded");
        return this._rewardedFeatureEnabled;
    }

    static isRewardedAdAvailable(eventID) {
        if (!APIMediator.areRewardedAdsSupported()) return false;
        if (!eventID) console.warn('no eventID set in isRewardedAdAvailable() call');

        return window.GameInterface.isRewardedAdAvailable(eventID);
    }


    static watchRewardedVideo(eventID) {
        if (!eventID) console.warn('no event ID set is watchRewardedVideo() call');

        return new Promise((resolve, reject) => {
            if (APIMediator.isRewardedAdAvailable(eventID)) {
                window.GameInterface.showRewardedAd(eventID).then((result) => {
                    resolve(result.isRewardGranted);
                })

            } else {
                resolve(false);
            }
        });
    }

    /* GDPR */
    static isGDPREnabled() {
        return APIMediator.hasFeature("gdpr");
    }


    /** UI  */
    static isScoreVisible() {
        return APIMediator.hasFeature("score");
    }

    static isProgressVisible() {
        return APIMediator.hasFeature("progress");
    }

    static isVersionEnabled() {
        return APIMediator.hasFeature("version");
    }

    static isBombPowerupEnabled() {
        return true;
    }


    /** pause */
    static isPausingAllowed() {
        return APIMediator.hasFeature("pause");
    }

    static isPaused() {
        return window.GameInterface.isPaused();
    }

    static onPauseStateChange(callback) {
        window.GameInterface.onPauseStateChange(isPaused => {
            callback(isPaused);
        });
    }

    /** audio **/
    static areAudioControlsAllowed() {
        return APIMediator.hasFeature("audio");
    }

    static isMuted() {
        return window.GameInterface.isMuted();
    }

    static onAudioStateChange(callback) {
        window.GameInterface.onMuteStateChange(isMuted => {
            callback(isMuted);
        });
    }


    static reportGameMuted(state) {
        state = !!state;
        if (state !== this._lastReportedMuteStatus) {
            this._lastReportedMuteStatus = state;
            window.GameInterface.gameMuted(state);
        }
    }
    
    /* level tracking */
    static trackLevelStart(level) {
        const data = {
            "level": level
        }
        window.GameInterface.track("event/level/start", data);
    }

    static trackLevelEnd(level, success) {
        const data = {
            "level": level,
            "success": success
        };

        window.GameInterface.track("event/level/end", data);
    }
    
    static trackLevelUpdate(level, revives) {
        const data = {
            "level": level,
            "revives": revives
        };
        window.GameInterface.track("event/level/update", data);
    }


    /* IAP */
    static getProducts() {
        return window.GameInterface.iap.getProducts();
    }

    static areInAppPurchasesSupported() {
        return APIMediator.hasFeature("iap");
    }

    static buyProduct(sku) {
        return window.GameInterface.iap.buyProduct(sku);
    }

    static registerIAPEventListeners() {
        const app = pc.AppBase.getApplication();
        window.GameInterface.iap.onEvent((event) => {
            app.fire(EventTypes.PURCHASE_EVENT, event);
        });
    }

    static consumeProduct(purchase) {
        window.GameInterface.iap.consumeProduct(purchase)
            .then(() => {
                APIMediator.log(`[IAP] Product consumed`);
            })
            .catch(error => {
                console.error(`[IAP] Failed to consume product`, error);
            });
    }

    /** storage **/
    static getStorageObject() {
        return window.GameInterface.storage;
    }

    /** extra features */
    static isPrivacyPolicyEnabled() {
        return APIMediator.hasFeature("privacy");
    }


    static isCopyrightEnabled() {
        return APIMediator.hasFeature("copyright");
    }

    static isTutorialEnabled() {
        return APIMediator.hasFeature("tutorial");
    }

    /** misc */
    static skipHomeScreen() {
        return !APIMediator.hasFeature("home");
    }

    /** callbacks  */
    static initCallbacks() {
        const app = pc.AppBase.getApplication();

        window.GameInterface.onRestartGame(() => {
            /* restart level/gameplay */
            app.fire(EventTypes.RESTART_CURRENT_LEVEL);
        });

        window.GameInterface.onQuitGame(() => {
            /* quit level/gameplay */
            app.fire(EventTypes.EXIT_TO_MAIN_MENU);
        });

        window.GameInterface.onGameOver(() => {
            /* quit level/gameplay */
            app.fire(EventTypes.FORCE_GAME_OVER);
        });

        window.GameInterface.onGoToHome(() => {
            /* go to home */
            app.fire(EventTypes.EXIT_TO_MAIN_MENU);
        });

        window.GameInterface.onGoToNextLevel(() => {
            /* go to next level */
            app.fire(EventTypes.LOAD_NEXT_LEVEL);
        });

        window.GameInterface.onGoToLevel(level => {
            /* go to level x */
            app.fire(EventTypes.LOAD_CUSTOM_LEVEL, level);
        });

        if (!window.GameInterface.hasFeature("visibilitychange")) {
            APIMediator._injectPlaycanvasAvoidVisibilityHack();
        } else {
            APIMediator._addVisibilityChangeHandler();
        }
    }

    /* avoid visibility hack */
    static _injectPlaycanvasAvoidVisibilityHack() {
        /** 
         * A snippet that forces the Playcanvas app to be rendered even if the tab/page focus is lost.
         * In other words, it just disables 'pause' feature. 
         * @author Igor Parada
         */
        (function () {

            const detectApplication = () => {
                if (typeof pc !== 'undefined') {
                    const ApplicationClass = pc.AppBase || pc.Application;
                    if (ApplicationClass && ApplicationClass.getApplication()) {
                        injectHack();
                    }
                }
            };
            const _hookApplicationStart = setInterval(detectApplication, 100);

            const injectHack = () => {
                clearInterval(_hookApplicationStart);

                console.log('Injecting do-not-pause hack...')

                const ApplicationClass = pc.AppBase || pc.Application;
                const app = ApplicationClass.getApplication();
                const initialPlatformWasBrowser = pc.platform.browser;

                const MANUAL_RENDER_FPS = 60;

                let _hiddenAttr = 'hidden';
                let _manualRenderInterval = undefined;

                const setupManualRenderLoop = () => {
                    if (_manualRenderInterval) {
                        console.warn('manual render is already active!');
                        return;
                    }
                    const averageFPS = app.stats && app.stats.frame && app.stats.frame.fps || MANUAL_RENDER_FPS;
                    _manualRenderInterval = setInterval(() => app.tick(), 1000 / Math.min(averageFPS, MANUAL_RENDER_FPS));
                }

                const disableManualRenderLoop = () => {
                    if (_manualRenderInterval) {
                        clearInterval(_manualRenderInterval);
                    }
                    _manualRenderInterval = undefined;
                }

                const onDocumentHidden = () => {
                    setupManualRenderLoop();
                }

                const onDocumentRestored = () => {
                    disableManualRenderLoop();
                    if (_manualRenderInterval) {
                        app.tick();
                    }
                }

                const _visibilityChangeHandler = () => {
                    const documentHidden = document[_hiddenAttr];
                    if (documentHidden) {
                        onDocumentHidden();
                    } else {
                        onDocumentRestored();
                    }
                };


                const addVisibilityChangeListeners = () => {
                    // Depending on browser add the correct visibilitychange event and store the name of the
                    // hidden attribute in this._hiddenAttr.
                    if (typeof document !== 'undefined') {
                        if (document.hidden !== undefined) {
                            _hiddenAttr = 'hidden';
                            document.addEventListener('visibilitychange', _visibilityChangeHandler, false);
                        } else if (document.mozHidden !== undefined) {
                            _hiddenAttr = 'mozHidden';
                            document.addEventListener('mozvisibilitychange', _visibilityChangeHandler, false);
                        } else if (document.msHidden !== undefined) {
                            _hiddenAttr = 'msHidden';
                            document.addEventListener('msvisibilitychange', _visibilityChangeHandler, false);
                        } else if (document.webkitHidden !== undefined) {
                            _hiddenAttr = 'webkitHidden';
                            document.addEventListener('webkitvisibilitychange', _visibilityChangeHandler, false);
                        }
                    }
                }

                const removeVisibilityChangeListeners = () => {
                    if (typeof document !== 'undefined') {
                        document.removeEventListener('visibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('mozvisibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('msvisibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('webkitvisibilitychange', _visibilityChangeHandler, false);
                    }
                }

                app.on('destroy', () => {
                    removeVisibilityChangeListeners();
                });

                /** path the playcanvas engine */
                ApplicationClass.prototype.isHidden = () => false;
                ApplicationClass.prototype.onVisibilityChange = () => {
                    //just a stub to prevent pausing the sound subsystem
                };

                /** entry point */
                addVisibilityChangeListeners();
            }

        }());
    }


    /* pause-due-to-focus-lost handling */
    static _addVisibilityChangeHandler() {
        (function () {

            const detectApplication = () => {
                if (typeof pc !== 'undefined') {
                    const ApplicationClass = pc.AppBase || pc.Application;
                    if (ApplicationClass && ApplicationClass.getApplication()) {
                        addPauseHandlers();
                    }
                }
            };
            const _hookApplicationStart = setInterval(detectApplication, 100);

            const addPauseHandlers = () => {
                clearInterval(_hookApplicationStart);

                const ApplicationClass = pc.AppBase || pc.Application;
                const app = ApplicationClass.getApplication();

                let _hiddenAttr = 'hidden';

                const getAudioContext = () => app.soundManager && app.soundManager.context;

                const onDocumentHidden = () => {
                    pc.AppBase.getApplication().timeScale = 0;
                    // Explicitly suspend the AudioContext
                    const ctx = getAudioContext();
                    if (ctx && ctx.state === 'running') {
                        try {
                            ctx.suspend();
                        } catch (e) {
                            console.warn('[AUDIO] Failed to suspend AudioContext:', e);
                        }
                    }
                };

                const onDocumentRestored = () => {
                    // Always resume the AudioContext regardless of game-pause state
                    const ctx = getAudioContext();
                    if (ctx && ctx.state === 'suspended') {
                        try {
                            ctx.resume();
                        } catch (e) {
                            console.warn('[AUDIO] Failed to resume AudioContext:', e);
                        }
                    }
                    if (!APIMediator.isPaused()) {
                        pc.AppBase.getApplication().timeScale = 1;
                    }
                };

                const _visibilityChangeHandler = () => {
                    const documentHidden = document[_hiddenAttr];
                    if (documentHidden) {
                        onDocumentHidden();
                    } else {
                        onDocumentRestored();
                    }
                };

                // pagehide / pageshow as a fallback when visibilitychange is late or missing.
                const _pageHideHandler = () => onDocumentHidden();
                const _pageShowHandler = () => onDocumentRestored();

                const addVisibilityChangeListeners = () => {
                    if (typeof document !== 'undefined') {
                        if (document.hidden !== undefined) {
                            _hiddenAttr = 'hidden';
                            document.addEventListener('visibilitychange', _visibilityChangeHandler, false);
                        } else if (document.mozHidden !== undefined) {
                            _hiddenAttr = 'mozHidden';
                            document.addEventListener('mozvisibilitychange', _visibilityChangeHandler, false);
                        } else if (document.msHidden !== undefined) {
                            _hiddenAttr = 'msHidden';
                            document.addEventListener('msvisibilitychange', _visibilityChangeHandler, false);
                        } else if (document.webkitHidden !== undefined) {
                            _hiddenAttr = 'webkitHidden';
                            document.addEventListener('webkitvisibilitychange', _visibilityChangeHandler, false);
                        }
                    }
                    window.addEventListener('pagehide', _pageHideHandler, false);
                    window.addEventListener('pageshow', _pageShowHandler, false);
                };

                const removeVisibilityChangeListeners = () => {
                    if (typeof document !== 'undefined') {
                        document.removeEventListener('visibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('mozvisibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('msvisibilitychange', _visibilityChangeHandler, false);
                        document.removeEventListener('webkitvisibilitychange', _visibilityChangeHandler, false);
                    }
                    window.removeEventListener('pagehide', _pageHideHandler, false);
                    window.removeEventListener('pageshow', _pageShowHandler, false);
                };

                app.on('destroy', () => {
                    removeVisibilityChangeListeners();
                });

                // entry point
                addVisibilityChangeListeners();
            };

            
        }());
    }
}

